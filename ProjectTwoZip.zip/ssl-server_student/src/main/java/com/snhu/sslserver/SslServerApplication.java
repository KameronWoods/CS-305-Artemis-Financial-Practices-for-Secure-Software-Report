package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;


@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {
	
	 @GetMapping("/hash")
	    public String myHash() {
	        String data = "Kameron Woods Hello World Hash";
	        String hash = generateChecksum(data);
	        return String.format("<p>Data: %s<br>Checksum: %s</p>", data, hash);
	    }

	 private String generateChecksum(String data) {
	        if (data == null) {
	            return "Error: Input data is null";
	        }
	        {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); 
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash);
        } catch (Exception e) {
            return "Error generating checksum";
        }
	       }
    }

	        private String bytesToHex(byte[] bytes) {
	            StringBuilder hexString = new StringBuilder(2 * bytes.length);
	            for (byte b : bytes) {
	                String hex = Integer.toHexString(0xff & b);
	                if (hex.length() == 1) {
	                    hexString.append('0');
	                }
	                hexString.append(hex);
	            }
	            return hexString.toString();
    }
}

